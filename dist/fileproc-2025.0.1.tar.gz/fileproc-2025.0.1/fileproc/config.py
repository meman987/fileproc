# <CONNECT_STR = "postgresql+psycopg2://fileproc:fileproc@localhost:5432/fileproc"
# CONNECT_STR = 'sqlite:///:memory:'
CONNECT_STR = 'sqlite:///fileproc.sqlite'
ECHO = True
