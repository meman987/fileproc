# Intro

***This is work in progress***

Keep track of python programs processing (massive amounts of) files.
Built using asyncio for processing PCAP-files, but can be used for
any type of file.


## Development

Dependecies: `pip3 install build twine`
